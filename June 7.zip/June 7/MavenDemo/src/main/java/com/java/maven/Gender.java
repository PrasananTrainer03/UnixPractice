package com.java.maven;

public enum Gender {

	MALE, FEMALE
}
