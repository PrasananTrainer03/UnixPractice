package com.java.maven;

public class EmployException extends Exception {

	public EmployException(String error) {
		super(error);
	}
}
