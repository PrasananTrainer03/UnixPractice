package com.java.ex;

public class SbExample {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("Welcome to Java Programming...\n");
		System.out.println(sb);
		sb.append("Java Training going on...Prasanna Trainer here...");
		System.out.println(sb);
	}
}
