package com.java.segue;

public class LoopEx1 {

	public void show() {
		int i=0;
		while(i <= 10) {
			System.out.println("Welcome to Java Programming...");
			i++;
		}
	}
	public static void main(String[] args) {
		LoopEx1 obj = new LoopEx1();
		obj.show();
	}
}
