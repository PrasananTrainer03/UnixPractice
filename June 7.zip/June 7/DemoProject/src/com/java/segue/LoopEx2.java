package com.java.segue;

public class LoopEx2 {

	public void show() {
		for(int i=0;i<10;i++) {
			System.out.println("Welcome to Java...");
		}
	}
	public static void main(String[] args) {
		LoopEx2 obj = new LoopEx2();
		obj.show();
	}
}
