public class B {
    void show() {
        System.out.println("Hi");
    }
    public static void main(String[] args) {
        B b = null;
        b.show();
    }
}