public class P26 {
    public static void main(String[] args) {
        int[] a=new int[]{12,5,3,23,45};
        for(int i : a) {
            System.out.println(a);
        }
        
    }
}