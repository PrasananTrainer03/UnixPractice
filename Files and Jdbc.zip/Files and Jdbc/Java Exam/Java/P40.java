class Demo {
    static {
        System.out.println("Hi");
    }
}
public class P40 {
    public static void main(String[] args) {
        System.out.println("Bye");
    }
    static {
        System.out.println("Hello");
    }
}