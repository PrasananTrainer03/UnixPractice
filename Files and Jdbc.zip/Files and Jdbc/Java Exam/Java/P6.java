public class P6 {
	    public void check(int x) {
        	if (x=2) {
	            System.out.println("Hi");
        	} else {
	            System.out.println("Bye");
     	   }
	    }
	    public static void main(String[] args) {
        	new P6().check(2);
	    }
	}