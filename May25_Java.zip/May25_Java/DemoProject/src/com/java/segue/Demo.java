package com.java.segue;

class Data {
	
	public void gaurav() {
		System.out.println("Hi I am Gaurav Gawhane...");
	}
	
	void dorababu() {
		System.out.println("Hi I am Dorababu...");
	}
	
	private void charan() {
		System.out.println("Hi I am Charan Naga Raj...");
	}
}

public class Demo {
	public static void main(String[] args) {
		Data obj = new Data();
		obj.dorababu();
		obj.gaurav();
	}
}
