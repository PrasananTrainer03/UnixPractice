-- Distinct : Used to eliminate duplicate entries at the time of display

select job from Emp;

select distinct job from Emp;

