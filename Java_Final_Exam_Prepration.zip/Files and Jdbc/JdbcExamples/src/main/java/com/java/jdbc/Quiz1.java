package com.java.jdbc;

public class Quiz1 {

	public static void main(String[] args) {
//		int x;
//		System.out.println(x);
	}
}
