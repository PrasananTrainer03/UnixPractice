public class P38 {
    int sum() {
        return 5;
    }

    public static void main(String[] args) {
        System.out.println(sum());
    }
}