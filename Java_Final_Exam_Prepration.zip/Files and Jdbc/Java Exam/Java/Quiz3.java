public class Quiz3 {
    public static void main(String[] args) {
        System.out.println("5" +3+8); // 538
        System.out.println("5+3" +8); // 5+38
        System.out.println("5" + (3+8)); // 511
        System.out.println("5" -3+8); // Compile-Time
        System.out.println("5" +3-8); // Compile-Time
    }
}