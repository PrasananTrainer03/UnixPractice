public class Prog1 {
    public static void main(String[] args) { 
        int anInt = 100; 
        long aLong = 200L; 
        byte aByte = 99; 
        short aShort = -902; 
        char aChar = 'A'; 
        float aFloat = 99.98F; 
        double aDouble = 999.89; 
        System.out.println("anInt = " + anInt); 
        System.out.println("aLong = " + aLong); 
        System.out.println("aByte = " + aByte); 
        System.out.println("aShort = " + aShort); 
        System.out.println("aChar = " + aChar); 
        System.out.println("aFloat = " + aFloat); 
        System.out.println("aDouble = " + aDouble); 

} 
}