package com.java.sup;

public class Ayushi extends Employ {

	public Ayushi(int empno, String name, double basic) {
		super(empno, name, basic);
	}
	
}
