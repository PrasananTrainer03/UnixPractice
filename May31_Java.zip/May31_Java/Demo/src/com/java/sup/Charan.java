package com.java.sup;

public class Charan extends Employ {

	public Charan(int empno, String name, double basic) {
		super(empno, name, basic);
		// TODO Auto-generated constructor stub
	}

}
