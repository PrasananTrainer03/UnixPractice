package com.java.segue;

class Data {
	
	public void sowmya() {
		System.out.println("Name is Sowmya T.S.");
	}
	
	private void sumanth() {
		System.out.println("Hi I am Sumanth...");
	}
	
	void saritha() {
		System.out.println("Hi I am Saritha...");
	}
}

public class Demo {

	public static void main(String[] args) {
		Data obj = new Data();
		obj.sowmya();
		obj.saritha();
	}
}
