export class Employ {

     constructor(public empno : number,
                public name : string,
                public dept : string,
                public desig : string,
                public basic : number 
        ) {}
}
