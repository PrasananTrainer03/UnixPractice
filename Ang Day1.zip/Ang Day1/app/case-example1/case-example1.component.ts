import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-case-example1',
  templateUrl: './case-example1.component.html',
  styleUrls: ['./case-example1.component.css']
})
export class CaseExample1Component implements OnInit {

  choice : number;
  constructor() { }

  ngOnInit(): void {
  }

}
