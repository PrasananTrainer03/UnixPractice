package com.java.segue;

public enum Gender {

	MALE, FEMALE
}
