package com.java.emp;

public class EmployException extends Exception {

	EmployException(String error) {
		super(error);
	}
}
